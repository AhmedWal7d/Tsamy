import './App.css';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import Home from './Components/Home/Home'
import Products from './Components/Products/Products'
import Cart from './Components/Cart/Cart'
import Brands from './Components/Brands/Brands'
import Login from './Components/Login/Login'
import Register from './Components/Register/Register'
import Categories from './Components/Categories/Categories'
import Layout from './Components/Layout/Layout'
import ForgetPassword from './Components/ForgetPassword/ForgetPassword';
import ResetPassword from './Components/ResetPassword/ResetPassword';
import UserContextProvider, { UserContext } from './Components/UserContext/UserContext';
import ProtuctRout from './ProtecdRout/ProtuctRout';
import { useContext } from 'react';



let routes = createBrowserRouter([
  { path: '/', element: <Layout />, children: [
    {index:true , element:<ProtuctRout><Home/></ProtuctRout>},
    {path:'Products' , element:<ProtuctRout><Products/></ProtuctRout>},
    {path:'Cart' , element: <ProtuctRout><Cart/></ProtuctRout>},
    {path:'Categories' , element:<ProtuctRout><Categories/></ProtuctRout>},
    {path:'Brands' , element: <ProtuctRout><Brands/></ProtuctRout>},
    {path:'Login' , element:<Login/>},
    {path:'ForgetPassword' , element:<ForgetPassword/>},
    {path:'Register' , element:<Register/>},
    {path:'ResetPassword' , element:<ResetPassword/>},
  ] }
])

function App() {

  
  return <UserContextProvider>
 <RouterProvider router={routes}></RouterProvider>
  </UserContextProvider>
  
}

export default App;
