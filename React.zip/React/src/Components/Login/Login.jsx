import React, { useContext, useState } from 'react';
import { useFormik } from 'formik';
import * as yup from "yup";
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { UserContext } from '../UserContext/UserContext';


export default function LoginSubmit() {

    let {setUserToken} = useContext(UserContext)
    let navigate = useNavigate();
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(false);

    async function handleLoginSubmit(values) {
       
        try {
            setIsLoading(true);
            const { data  } = await axios.post("https://cmask.net/front-api/login?lang=ar", values);



            if (data.status == true) {
                setIsLoading(false);
               localStorage.setItem("UserToken" , data.data.token)


            //    console.log("Welcome", UserToken );

                setUserToken(data.data.token)
                navigate("/");
            }
        } catch (error) {
            setIsLoading(false);
            if (error.response) {
                console.error("Server Error:", error.response.data);
                setError(error.response.data.message);
            } else {
                console.error("Error:", error.message);
                setError("An error occurred");
            }
        }
    }

    function validate(values) {
        console.log(values); // Log form values
    }

    const egyptianPhoneNumberPattern = /^(\+201|01|00201)[0-2,5]{1}[0-9]{8}/;

    let validationSchema = yup.object({
        phone: yup.string().matches(egyptianPhoneNumberPattern, "Phone number is not valid").required("Phone number is required"),
        password: yup.string().required("Password is required"),
    });

    let formik = useFormik({
        initialValues: {
            phone: "",
            password: "",
        },
        validationSchema,
        onSubmit: handleLoginSubmit
    });

    return (
        <div className='w-50 mx-auto py-5'>
            {error && <div className='alert alert-danger'>{error}</div>}

            <form onSubmit={formik.handleSubmit}>
                <h5 className='fw-bold text-center'>Login account</h5>

                <label htmlFor='phone' className='mt-2'>Phone:</label>
                <input type='tel' className='form-control mt-2' id="phone" onBlur={formik.handleBlur} name='phone' value={formik.values.phone} onChange={formik.handleChange} />
                {formik.errors.phone && formik.touched.phone && <div className='alert alert-danger'>{formik.errors.phone}</div>}

                <label htmlFor='password' className='mt-2'>Password:</label>
                <input type='password' className='form-control mt-2' id="password" onBlur={formik.handleBlur} name='password' value={formik.values.password} onChange={formik.handleChange} />
                {formik.errors.password && formik.touched.password && <div className='alert alert-danger'>{formik.errors.password}</div>}

                {isLoading ? (
                    <button className='btn bg-main btn-add-card mt-2' type="button">
                        <button className='btn bg-color btn-add-card '>  <i className="fas fa-spinner fa-spin"></i></button>
                    </button>
                ) : (
                    <button disabled={!(formik.isValid && formik.dirty)} className='btn btn-add-card w-100 border-radius p-8' type="submit">Login</button>
                )}
                <p className='mt-4'>This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply</p>
                <div className='d-center flex-column'>

                    <div className='d-flex mt-3'>
                        <p className='mx-3 mt-3'>New customer?</p>
                        <Link to={"/Register"} className='mt-3'>Create your account</Link>
                    </div>
                    <div className='d-flex '>
                        <p className='mx-3'>Lost password ?</p>
                        <Link to={"/ForgetPassword"} className='  '>Recover password</Link>

                    </div>


                    <div class="mt-3 w-50">
                        <button class="btn btn-add-card p-8 w-100 border-radius background-facebook d-flex justify-content-center align-items-center">  
                        <div class="d-flex m-0 p-0">
                            <p class="text-white mx-2 m-0 p-0">Sign in With Facebook</p>
                            <span class="text-white"><i class="fa-brands fa-facebook-f"></i></span>
                        </div>    
                        </button>
                    </div>
                    <div class="mt-2 w-50">
                        <button class="btn btn-add-card bg-danger w-100 border-radius d-flex justify-content-center p-8 align-items-center">  
                        <div class="d-flex m-0 p-0">
                            <p class="text-white mx-2 m-0 p-0">Sign in With Google</p>
                            <span class="text-white"><i class="fa-brands fa-google"></i></span>
                        </div>    
                        </button>
                    </div>

                </div>


            </form>
        </div>
    );
}
