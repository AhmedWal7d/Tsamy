import React, { useState, useEffect } from 'react';
import axios from 'axios';

const SearchAPI = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      if (searchTerm.trim() === '') {
        setSearchResults([]);
        return;
      }

      try {
        setLoading(true);
        const response = await axios.get(`https://cmask.net/front-api/home-search?lang=en&name=${searchTerm}`);
        setSearchResults(response.data.results);
        setLoading(false);
      } catch (error) {
        setLoading(false);
        setError('An error occurred. Please try again later.');
      }
    };

    fetchData();
  }, [searchTerm]);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  return (
    <div>
      <input
        placeholder="Search..."
        value={searchTerm}
        className="form-control h-45"
        type="search"
        id="exampleInputEmail1"
        onChange={handleSearch}
      />

      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}

      <ul>
        {searchResults.map((result, index) => (
          <li key={index}>{result.data}</li>
        ))}
      </ul>
    </div>
  );
};

export default SearchAPI;
