import React from 'react';
import styles from './Brands.module.css';

export default function Brands() {
  return <>
    <h1>Brands</h1>
  </>
}
