import React from 'react'
import { Link } from 'react-router-dom'

export default function Footer() {
  return<>
    <footer className=" bg-light text-muted">


<section className="">
    <div className="container  mt-5">
      
        <div className="row mt-3">
         
            <div className="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4 pt-4">
             
                <h6 className="mx-4 text-uppercase fw-bold ">
                    MOST SEARCHED
                </h6>

                <p>
                    <Link className="text-reset mx-4"> PC COMPONENTS</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">SOUND SYSTEMS </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> LAPTOPS </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">  SMART WATCHES & BANDS </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> CASHIER SYSTEMS </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> BARCODE PRINTER </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">ROUTER </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> SURVEILLANCE CAMERAS </Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">  HAIR STRAIGHTENER </Link>
                </p>

            </div>
         
            <div className="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4 pt-4">
          
                <h6 className="text-uppercase fw-bold mb-4 mx-4">
                    IMPORTANT LINKS
                </h6>
                <p>
                    <Link className="text-reset mx-4"> ABOUT US</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> CONTACT US</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">STORES LOCATOR</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">TERMS AND CONDITIONS</Link>
                </p>
            </div>
           
            <div className="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4 pt-4">
            
                <h6 className="text-uppercase fw-bold mb-4 mx-4">
                    SHOP WITH US
                </h6>
                <p>
                    <Link className="text-reset mx-4"> NEW ARRIVED</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">  BLACK + DECKER</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> RUSH BRUSH</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">SAMSUNG</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">LENOVO</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4"> TP-LINK</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">APPLE</Link>
                </p>
                <p>
                    <Link className="text-reset mx-4">EZVIZ</Link>
                </p>
                <p>
                    <a href="" className="text-reset mx-4">MSI</a>
                </p>
            </div>
          
            <div className="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4 pt-4">
                
                <h6 className="text-uppercase fw-bold mb-4 mx-4"> SUBSCRIBE NOW</h6>
                <p className="mx-4">to keep up to date with the latest arrivals andexclusive offers direct to your inbox.</p>

                <p className="mt-5 mx-4"><input type="email" placeholder="E-mail (ex@gmail.com)"
                        className="footer-inp form-control bg-white mx-2"/>
                    <button className="btn footer-btn text-white mt-3">Subscribe</button>
                </p>

            </div>
          
        </div>
       

    </div>
    <div className="row">

        <div className="col-md-4 ">
            <div className="text-center ">
                ©2023 - active4web | : 403-932-068 . All Rights Reserved.
            </div>
        </div>
        <div className="col-md-4 ">
            <div className="d-flex justify-content-around w-75">
                <div className="footer-img">
                    <img src="img/visa-img-logo.png" className="w-100" alt=""/>
                </div>
                <div className="footer-img">
                    <img src="img/logoFooter.png" className="w-100" alt=""/>
                </div>
                {/* <!-- <div className="footer-img">
            <img src="data:image/png;base64,iVdBORw0KGgoAAAANSUhEUgAAAMgAAAA/CAYAAAClz4c/AAAAAXNSR0IB2cksfwAAFXdJREFUeJztXQnY1lMWx2TNhFtaKLIV2dfIUso2Y5J9jbFkG8KMPbuETIqsfdYvYwkZGssYjIjkwdjJZMmuw6BSUvjm/Jz7jdf7v/fc+9/evub5zvP8np7e7z13ee89dznbXWihZppv1HF0HdCf8QqDGJMYPYoqnw5YeiPGRYwHGC8y3mG8x3iN8XfGpYw+jMWLqjNF2zoyBjLuYjzLmGLbNpnxFGM0oz/j1yXVvyrjBcYn9rfZuIx6mikHsTAMZHzLaKjA3DxCgsnOONcKQ0MkPrXCYorsn6NtLRg7MyYy5kW27VvG/YxNC27LEVX1nFRk+c2Uk1gI2tido8GBCVnK5EE+kPFhCsGoxgwrXIsU2VcuD9iMMYHxY8a2zWHcwVi5oDbtXVX+0UWU20wF0Yqj67ZkQZjmEZAfTH1d9CTFMYRxbw7BqMZ4Rtui+splncyYWVDbPmLslbL+jaxwDmG0tJ/1rCp3f/s5drnzGM8xdi3qN2imlNSuvq4XC8kXLgHhzxtYQBaLKYcHcT3GkwUKRyPeZ2yL1T8rWcG9Jseu4cM3jD8ygr8Rf2cJkjtXg23HS4w9GJvQL495uzB628Wh8bNpmTvfTPmIBaBXe4+AtK2PExAewC4kF9qihaMRn1HGyyvJXWhUiW3D3QSX/BaBdmzo4MVRsp7k2Nb42d0Mqv5ulr43UwEEAWldX/dF+3rZMRp3jnayewQFhAfPkByr0qzO+O4PKSciVtSOafpGcuc4LWXbGjK0DRO9Fym7HP9taRKN3ayUZX/HmJim381UIEFAGF9AGNowlrf/mvqwgPDALcw4xw5iaKBxab+P5Fx9JGMA43QS9eq7jO8D/Pj7SMaisX3j765JcgyKmeAQwGGMYxmHMk5gXM14PrJ/TzBWDLRnMcYhjMcofBfCroJdGVquUlTMzRRBlQLigSYgsCG8HxhoTISbGBtAoBxlNE7koYyPA2V9ztghpl/8vV8x7gmUN89O1t0ZS3jKwcp/NOPVCCE5BfVGtG0ZxhmMrz3lfGcXg5YxfW2mEimrgJDsHiMCEwZn6W1dguEoD1iXxEinlYljSsy9qE+gHNwdTqJI46Sd1DeTflyDgK8dKKcr4zLGtED7vmJcR3K/C/5+zVQS5RCQDiSqTm0Cbp62PXZCJC6pFfiSsWOgDOBvgZ1jWMxqX1UuLvxjAxP7VNeEJtnRLmF8EbETVQK7TH3a37GZCqIcArJHYDUdkrVNzNs3UPaIAH970i3k/2C0yti2boy3lbIfZ7Rx8G3s6BPuVW8w5lZ89lbV/3/C/wriAVmC0ZWRqKSWxPV3YKyO9pRYx2KMVRlbMfox9mXsx9iV0ZPRhVGqf1IWASE5XmnnewzyklnbxLyLBFZq+Ex5L+uUtE5XAveY7XK0DX0/Uil/NqO7gw+2mKkV3/uARCGweZVA4D60P+P1is+m/1QID8aBjGcY7zFeYQxhtM7amSzE9RnGlYzJjHcZjzF2YxRR9sKMNRlHMG5mTGK8wyDGTMYci28Yn9vf4VnGaMZxjA3TWLYj25RFQHBxnaxMksF528Vl7KCUD41YO4V3eGD3iDJ+KuWvQbqP2UEevv2skED4u5Mcu3pU8e5thRA71RgS/7RTF7Ir6MyqwfmOcTkmVp4OpSGu607Gj1Xt+IihXr4CZba0/bvTTvp5yoT04XvbjrGM/ozspuVfti2LgKxoB843QTbM2y4uoxX5Vb9Qy3ZReB9V2nZBAW2DVfx2pY6zPHzYGVdjLFfxWb8q3sMr/oaFqOtPAs0D8ZRngD5hpDIQZSWup7syea/MUB6Oi3syHmZMzyAUPsxmPGLkOLZUzj5nEZDVya+inJd3ha6ox6fpQR3rK3y+3Q0Cd1gB7QIuVAREvSNVlTWgivdE5xd5ID7zDBBW82PzdiqGuJ6/KBNlUsqyVmHcxvi6QMGoxgzGXYzMMQQZBaSLXcVdk2Nm1rY46pmqTEJvn0nO9y4eaNb2Lqhtg5S2XZGiHBy1GrV2uB+5NXQ8EP9SBgn3gVKtiSif8a3ShtEpysJl+5sSBcO1oxycsd9NWUDeyyggPld7XKD3KKhtpxchILYsHL2WIk3tzANxijJIOH9vn7tXChk51/vqn8vYMqKMRRiX1lAwqnENQ3Wac7S5pgJijye4X7ShgAFsfggI/31JRjt1si5UrIBEEQ/E0iZ5Sa/EQ4xUhp0UdUO79KJSNzRq6lkfbWNclmNyY/eC5mqa0XeyEMalEZJaCgj/rTPjTpI7BGwCkxjdlO/XTED485YkfmWNdyt4EB+g1FFbAQEZ/Q6As3zXkurdNDDpLg7wQ8CGp5zIbzOuZ+zDWMlRZltGX8Yoxr9NUrOm4VoTqQ6ulYDw523JHS8Cff8qHp6aCIjd1UaS2zi5n6eO+SIgawQmQikVG7lM++r8gLFugP/iyImLo+IYxmaxE9iWj6NbN8ZVJl5FHPVb1VBADlYm1CkenloJCCzvPreZtzx11F5AQDwgE5TB+pDhNRBlrG9FO3F9dd5qFCOhXeVjJuwbjC1MDpuOkZ1qEyMGxpg6vUeEijJrJSDahBrp4amVgGj9mZGhP6UKyP7KYGF36VdwfScq9eFOtJvCC+F6KWLXqDcFegQYsa/URewm0KQ5jy8VZTUFAXFOqCYiIIX1pxAyctn9WBkwuF0U4h/F5SxqxBDpq+tphtenyIhLinYkhNvIYNRTRHur6m7BOMOEL/Q3GH0HbBaQBUlAQDwof1YGDBbpQpKaGXEK9NUDN5eBCu9OgYmFjCAnmYJ9p6ragLvJQKMbI78K7II9jWjPmqKAaF6zTld6kgu3zw1mlkdA4M7hi/BrkgKytdFVvheanCpfO7luUerAnSGhXbK88MIdG1i5b3dNrqLJ7iRDA215wLcTYrExolr28SZ264CAzHbVQxIn4ZtQdeSOoXhJ4TmeHDHgpLu6T2f81sHTze4uLp6vPf05W2mb805VGPGgtGL8VRm0Nxmr5qxjHSMaKl8dlyu82wZWXahwC1UmBPrS2gq0toskJoblhYpbO2YuU81Dki7zS8/kgKo0caTkz/6gTCi4zifsTCQx7D4e+FutUSkkJAFN5yg8cEFZx1EPPGp9iRo+dP1uJCHCvnqGBoYsPxlxff9BGbhDTQ4XdOY9N1D+Nh4+4AqFD3cS75GmLDJy5NP6A5tLYpXmz9YOLBQrVPNQ2Js3sfOSBFj5vo+ctImEB/zZiQoPAEPjXpj0jC1IIvamK9+HHSYRX0N6fMfzju/DNaRO4Tkj3ehlIBxvGK8qA/cgY9mMZSPm4zmlbKzGzos1f74U42WFF/Esqdw9iiAjR8ZHA7tuYrLb33mKwrdWNQ9PgOVIj4dIBCSROOUlIuXo57tBIuctf7YChbN/YMeC9Tsm88jZjjoQezFG4Rnr4EHwkxbSe2S60ctARnT+pykDB/+onTKWPcDIJdxX9oEKL1bcWQpvVNaNMshIZKKvXdCo9XfwtAwIfK9qHpJAnxeUCXK6g2cl+mWUXDX+RO47xciIiR8DCFoibILEwu/z/gUSRkz+bGXGmwrPzmnGLTPx4KxnJNrON3ijMpTZwu4+vjLhQp44d1fwH67wQptU+sVcaRv6NlVp32UOHuBJhWdfV108CW5VJshdju/jfnCLwoP0OwlbEUk2kTQZ4n04xtOP3ch//8DulAiUI0mA7duxcNnfIG7EchIPzuJGzs6+wYP2JVXMtgmrNYcF+G9VeB/K1+P8ZETD52sfgqxcPGMUnjNd9ZDEU/sm4xTPbqCd9XH86uupa1OSNDhZheNGcisOEBmopUx9j9zatUMVnldcO1VpxAO0ndEtxselKAu4TikLVu/VFX6odzXL+cnF9Do7cRt2UNqHu1VCW2R0NfH9rnpIMpXP8UwSrMiuuwsSxGnHGVyinXYjkhj1mORtlYC69xxyaMhsmQeT/14EXOLgwU54s8KDB3dqd4rgAVqO8ZYygC+7VkVPWVCHvq2UBVdxr6+Ukcv9uwp/z8I6npGMRDL62uf0ZePPjjJ+DRh228Sk5UmwPOlZFROJG0hSb16l8CAk1nnBJdEcwV6BLO2+cN9KQDN2gGvnsOXhTqQZIhF9mDAlkIQbv6vwnRA3UgWRXfXPDKz6W0eWtWdgN1Iv/fz3FYxuM1Bzs9aCuA1LKu3DZE88/MKf9WF8qfB1ruaxE1bT5GC1T7SPJMmzz8gIIPzU+4oTSUDTloyLSXJQQUinWz4cb3A3OoiUPLkkWijk3dVyb93j4e2v8EGotvLVWxoZcYPX3DrujCgD95nHlDJwn1F9vDC5jH5/yZwLqiiyC4rPPwxKhMQR0gq+tks7H3CxK7RvsmA3WNPBg9DSGwKrP5KpebOW2HKgnm1tV3TYQdYiyRWsjqEVsLPsZNZ2D2dSCJJk2z6+p6nAB3+iyYh25m5lAGe4jg5VZaxvv+cr49qIdjR5AQEpAoL+JyaeERvKw0q/nKly7DFFyzE73MO3WWAXAeBmslqRv4vdOc6nsG1ltGf36xhoNzLXl+Z7p5KRlDxzlEH0mveN2FRuUnhhU+kU0Qa4t3+qlNPUj1jOHcTyXaDwQQ2cMH5SOAcuLuudPXznBY44DXYy9nNN1rREEgP/YKA+ABq4NTxl1Ct8ELpNcjc0K9mBf14ZRFxAndIbMbEfjmzDgn5Jh0+Wc1Xmz3dR+PDbbebiI3nvQrNi3+ThQwz4+IgJC4xxCVoMMd+iJI+KxiSNhg3D6SZEcpTT+nkb5Ui3WgjxIB2iHB8Apxu8kbhvHw/g1L87yoGaV7M6O0NHa0nchu0zCsjyxq/Jwm8+yMVHYsh7LjDxfK7pOLJMjRQSrNDXkuSyjXn+ABZyqHFD75dU7nbe9z1Iz9YI3qg5VCrxILU3kn7TNwESaeKN+E7dpfBgR0jTBq2scYV2OANxG87OIiCW9wmFd7zxZ3rHQ5ZaNvXXfasrf74TSQaRmEncCCRYg1UeLu9wVkQ2+F2tQFxE8ipUmvIAPIfge0TnoAAvPIsz+QUWTkaSPvsGESvgSlXf72n0u0sq454RPy5fWbgEFx49mKJtiwQWkJCAHBDom8/SjRyyoRduE0a3Cn5c2jWbRJnAPehS367En3ci/Rk3aOuazjPNPEi/M3qe20EV30X47ojAoKe6ARrJLqI5K5aa4C7QNs1ZMUZA2hg9gYX3IReSrOSadggX7oSzZAU/ovom1Vg44AmAtwid3tckVvNQm8b7dp75QkbsGdpRAM6Ni9vvwn6ixTrclqF+eL9qwUnjC+90fNvG5REQW8YdCj92J599AA/faw6MAJ4oc8bZ2DLgRn9bjYQDceswWvraAjuL5lzZKPQbpRqkWhAP0gmBla6v/d4xgQmze8b66wLl9i62x1Ft2iLQplgB6R0ow5u53O4C2l0EmKJNKjsx+5E/8UJeQBMFQ6XXoZBEDa29MdIIvCHY9N4PNKK21YKpJtrvTFS+A91+JqunkUwgmsEQj+K0L7rfSnvaBHa1NAICo6yWhhW7iNdmRKJSDQkJ7hs9tMlFYnE/jjGR4p5y1oB7BrRZV5A4WXr7z39bluTCHirzcUaHqAGaH2QkSbSm8j3P6H5Xx5uMIbtG0gWFkjbALb50vbiRI+clEcIRJSC2TC03GYCXv3xetwimGhUxwTBhoX1Soy9J7CV4lgxGutdI3N5DBkZgrt2F8KLUaaTkAK6oq6PdXULRiXBWrL3PVRqyRwrfmyKAlhUF95KEO3bK+kNpfwAkpSvN9dkK6rEm/nGeWAFBInEt0wl2T++LWyS2kccjJjG8cg9nBJ+2sMceeBDvSKJWhrMhkj0g0Ao+UNCiwVKOe8Ngu5OtRxGuHyTHOoQEw9bhC55qBAyOvw+VOd/JHgW0zCcarsg7cW39SMqmJUrAhDyhjJ3ESHbFoxn/SdHvKAGx5Q8JlIUgK6/2hsRPKyYSEJoknOW7xUzmosnuUHC6jDFYfm93o/njb5WWjGQ+SSsceGwm8yunVfWvxXgtUB/SfyIgqbA0QEbSIp1vdOfLvAKC2BnNtR8ZHfc2yjGVxC099rKNGO+jqOL9vjKJxAWlu91xYhI+YGdBLEqprw4XSvYooMUxuIBdp7DXqowkr9Y0ag12l8EbI9uYHBlPjNh1cLR8JrBz5RYQWx9e49XueUgRq+YnI0kyNyVSSHC3wBPSeLdv+ay/U6A9sG3AMAmVtC9ZnGvnQKK4mmeryU0RR4FKYLC9xqqM9cN6PTiyfhgY7zGSzTD62GXkOLWRkXDhPE+7pRUQHCO19EgA3i9RHxcisUa/HDkZK7VOuEusTTmdAO0dAxkX8f74Pyns7l4J7C4DKfDiVJMlHpyuKVZTXDyd6URztgFOjDemmKhz7MQ7ywpLZyOewi0tEGbcyci76IOMPHegKR1KERDbN+xYWook/A0hu6Eny/D88f0UvgRXAypeRCfCx6o3SVbH5XwTluQyj6CoDiSBVDi2PUTy/kfauhGpiAQNTc/WEUtGYj20YKpKXG1KSiZtxCky9iGdSkAVDW0YnCbftHjHCvPcDOXdovClFhDbt9DTclAUIJw59OYgbAxw7dCyMobuAUh5iss/8nJBg3Uv427GWBItFjRacI6E1V6LGgwBQuV9anqBIiMx1aGJgxU483PJke3AUeiCjBM7LyBoyIrfSlnxswrIakaPxWmwQh20DZBcjnvaiRxjz6g1IIBDyJGja4ElI8YyLaYagLt26U5lRmwT0K5pb5wUDew2h5mffdCKFhDs0n0tv9YOPOUdtC7bYxDy++KtcS1kt5aA9R/RkdvRgqSpiiUj72T4Bg5aJmeGwJLa0hgDf5+Jf1MwC9AvPG0A15fK+gsVEFsmFiFklwnd9x6JXYhIrO4IgBpF/mzxZQO7GAK+YAsxVEB4b5MkrFzGf7SZyihFbRhok7G7yYSIiZUG0Mbh4o4M921MlS3C+FXf8HTOrKQwYhvRHjxtbNuANOWSXKrhmzW8hjsKtFMPkwRZIUn2gnsRjyXjTqGJien1QK1Ru6AK7mF3lDxq2tl2x9jZKMoG40+PimNmLl0+87djTA60M5iGyUckbvP7kGi8ZpVwjII/F3JqORMz/F+TEU3SOPOzcQvqVOT2LcwwmJeMqHH3sSvxqwGBQfthqUeMxoDYXZC/t4xJeuTirfXuBfUBGe41P7jri6iHxKgH13fEoiOMVnv7wwVoveA5PI4k3rxzEe1a4MmIXQHJC2qXRDgj2d0FsfZ46amPBd5R76TtEpHl7scYZiQjfaEx00a8AlxvI84rShCriSSbI3y84LCIF6uQOmiEFSC4sg+1grAvYxPy5ORtpmaqCbEg/Mb8Mi4G/lnRycSbKZ7+C1ar3wNvvVrXAAAAAElFTkSuQmCC" alt="">
        </div> --> */}


            </div>
        </div>

        <div className="col-md-4 d-flex justify-content-center ">


            <div className="d-flex justify-content-around w-50">
                <span className="icone-footer d-center"><a href="icone-footer" className="text-white fs-4"><i
                            className="fa-brands fa-instagram"></i></a></span>
                <span className="icone-footer d-center"><a href="icone-footer" className="text-white fs-4"><i
                            className="fa-brands fa-facebook-f"></i></a></span>
                <span className="icone-footer d-center"><a href="icone-footer" className="text-white fs-4"><i
                            className="fa-brands fa-linkedin-in"></i></a></span>
                <span className="icone-footer d-center"><a href="icone-footer" className="text-white fs-4"><i
                            className="fa-brands fa-whatsapp"></i></a></span>
            </div>
        </div>


    </div>
</section>

</footer>
  </>
}
