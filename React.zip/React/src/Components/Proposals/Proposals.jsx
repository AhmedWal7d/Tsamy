import axios from 'axios'
import React from 'react'
import { useQuery } from 'react-query'

import Slider from "react-slick";


export default function Proposals() {


    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 6,
        slidesToScroll: 1,
        responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 3,
                slidesToScroll: 3,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                initialSlide: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
          ]
      };
    function getCatogry(){
        return axios.get(`https://cmask.net/front-api/home?lang=en`)
    }

    let {isError , data , isLoading} = useQuery("catogrySlider" , getCatogry)
    data?.data.data.recommended_products.map((product) => {
        console.log(product.id);
      })
    // console.log(data?.data.data.slider.id , "Ahmed0111");

  return <>
      <div class="top-slider px-4 p-2 mt-5">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="fw-bold"> مقترحات</h5>
            <p class="font-13">عرض الكل</p>
        </div>
    </div>
      
      
  {
    data?.data.data.recommended_products? <Slider {...settings}>

        {data?.data.data.recommended_products.map((product) => <>
            <div class="product shadow post-slide  pt-0 mt-0" key={product.id}>
                 
                 <div class="product-img post-img text-center position-relative">    
                     <img src={product.image}   alt="" class="w-100     "  height={300}/>
                      
                     <div class="bg-bluo text-white px-2 d-inline-block rounded-pill position-absolute title-product">ORIGINAL USED </div>
                     <p class="mt-3 text-end px-3 text-50 border-0">{product.description.split(" ").slice(0,2).join(' ')}</p>
                     <p class=" px-3 font-13 cursor-pointer">{product.details.split(" ").slice(0,10).join(' ')}</p>
                     <h5 class="fw-bold text-end px-4"> {product.price} EGP</h5>
                 </div>
                 <div class="product-details " >
                     {/* <div class="product-rate text-end px-3">
                         <span class="font-13">الا يوجد تقيم</span>

                         <span><i class="fa-solid fa-star text-50"></i></span><span><i
                                 class="fa-solid fa-star text-50"></i></span><span><i
                                 class="fa-solid fa-star text-50"></i></span><span><i
                                 class="fa-solid fa-star text-50"></i></span><span><i
                                 class="fa-solid fa-star text-50"></i></span>
                     </div> */}
                     <div class="d-flex over-product text-start px-3 mt-3 ">
                     {product.available? <>
                          <p class="text-green px-2 cursor-pointer">متوفر</p>
                         <span class="mt-2 "></span>
                     </> : ""}
                       
                     </div>
                
                
               
                 </div>
             </div>
        </> )}

    </Slider> : ""
   }
   
      
 

  </>
}
