import axios from 'axios'
import React from 'react'
import { useQuery } from 'react-query'

import Slider from "react-slick";


export default function SliderCatogry() {


  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 8,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
    ]
  };
  function getCatogry() {
    return axios.get(`https://cmask.net/front-api/home?lang=en`)
  }

  let { isError, data, isLoading } = useQuery("catogrySlider", getCatogry)

  // console.log(data?.data.data.slider.id , "Ahmed0111");

  return <>



    {

      <div className='slider-cartCatogry'>
        {
          data?.data.data.slider_categories ? <Slider {...settings}>
            {data?.data.data.slider_categories.map((ategorie) => <img src={ategorie.image} height={200} />)}


          </Slider> : ""
        }
      </div>
    }






  </>
}
