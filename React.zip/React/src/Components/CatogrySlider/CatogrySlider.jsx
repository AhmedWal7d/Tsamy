import axios from 'axios'
import React from 'react'
import { useQuery } from 'react-query'

import Slider from "react-slick";


export default function CatogrySlider() {


    var settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
      
      };
    function getCatogry(){
        return axios.get(`https://cmask.net/front-api/home?lang=en`)
    }

    let {isError , data , isLoading} = useQuery("catogrySlider" , getCatogry)

    // console.log(data?.data.data.slider.id , "Ahmed0111");

  return <>
      
      
  {
    data?.data.data.slider? <Slider {...settings}>
        {data?.data.data.slider.map((slider) => <img src={slider.image_name} className='w-100' height={500}/>)}
    </Slider> : ""
   }
   
      
 

  </>
}
