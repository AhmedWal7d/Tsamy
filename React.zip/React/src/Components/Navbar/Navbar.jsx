import React, { useContext } from 'react';
import styles from './Navbar.module.css';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../../Assets/images/freshcart-logo.svg';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import { UserContext } from '../UserContext/UserContext';
import axios from 'axios';
import { useQuery } from 'react-query';
import SearchAPI from '../Search/Search';


export default function Navbar() {


  function getFeaturProduct() {
    return axios.get(`https://cmask.net/front-api/home?lang=en`)

  }
  let { data, isError, isLoading } = useQuery("feadurProducts", getFeaturProduct)

  data?.data.data.manu_categories.map((nav) => {
    console.log(nav.departments);
  })


  let { setUserToken } = useContext(UserContext)
  let Navegat = useNavigate()

  function LogOut() {
    localStorage.removeItem("UserToken")
    setUserToken(null)
    Navegat("/login")
  }

  return <>


    {setUserToken !== null ? <>

      <div className="header-posiion">
        <header className="main-header d-none d-lg-block">
          <div className="container-fluid">

            <div className="row">
              <div className="col-lg-2 px-4 ">
                <img src="https://kimostore.net/cdn/shop/files/kimo-store_logo_en_75x@2x.png?v=1678809421"
                  alt="logo" className="logo" />
              </div>
              <div className="col-lg-4">
                <div className="mt-2 d-flex">
                <SearchAPI className="form-control h-45" type="search"  id="exampleInputEmail1"/>

                  {/* <input 
                    aria-describedby="emailHelp" placeholder="Search.....  " /> */}
                  <div className=" search-header d-flex justify-content-center align-items-center">
                    <i className="fas fa-search"></i>
                  </div>

                </div>
              </div>

              <div className="col-lg-2 text-end mt-2">
                <div className="d-flex justify-content-around">
                  <div className="login mt-3">
                    <select className="form-select" aria-label="Default select example">
                      <option selected>اللغه العربيه</option>
                      <option defaultValue="1">English</option>
                      <div className="text-white">
                        <i className="fa-solid fa-chevron-down text-warning"></i>
                      </div>
                    </select>
                  </div>


                </div>
              </div>
              <div className="col-lg-2 mt-3">
                <Link to={"Login"} className="btn text-white font-14">
                  Login / Signup
                </Link>
                <div className='cursor-pointer' onClick={() => LogOut()}>LogOut</div>

              </div>
              <div className="col-sm-2 mt-3 ">
                <div className="d-flex">

                  <div className="shopping-cart position-relative">
                    <Link to={"Login"} className="color-headre text-white"> <span className="fs-4"><i
                      className="fa-solid fa-cart-shopping font-30"></i></span></Link>
                    <div className="position-absolute  counter-shop">0</div>

                  </div>
                  <div className="mx-3">
                    <Link to={"/Cart"}>
                      <h6 className="font-16 text-white mt-2"> Cart</h6>
                    </Link>

                  </div>
                </div>
              </div>
            </div>

            {/* <!-- NavBar Header -->

                <!-- NavBar Header --> */}

          </div>

        </header>
        <div className="container-fluid bg-white  d-none d-lg-block mb-0">
          <nav className="navbar navbar-expand-lg navbar-light  mb-0 pb-0">
            <button className="navbar-toggler" type="button" data-toggle="collapse"
              data-target="#navbarSupportedContentt" aria-controls="navbarSupportedContentt" aria-expanded="false"
              aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse mx-3" id="navbarSupportedContentt">
              <ul className="navbar-nav mr-auto">





                {/* --------------------------------------------- */}


                {
                  data?.data.data.manu_categories.map((nav) =>

                    <>
                    <div class="dropdown" key={nav.id}>
                  <button class="btn  dropdown-toggle nav-item dropdown" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                  {nav.name}
                  </button>
                  
                  <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <li class="dropdown-item">

                    {nav.departments.map((pro) => <>
                            <li className='flex-column'>
                        <li  href="#">{pro.name}</li>

                            </li>

                          </>)}

                  {nav.departments.map((Item) => <>
                  
                      <li href="#">{Item.name}</li>
                      <ul class="dropdown-menu">
                        <li class="dropdown-item">
                        {Item.subDepartments.map((Item) => <>

                          <li>{Item.name}</li>

                        </>)}

                      
                        </li>
                      
               
                      </ul>
                  </> )}
                    
                    </li>
                    
                  </ul>
                </div>





                      {/* <li class="nav-item dropdown" key={nav.id}>
                        <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                         
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                          {nav.departments.map((pro) => <>
                            <ul>
                              <a class="dropdown-item" href="#">{pro.name}</a>

                            </ul>

                          </>)}





                        </ul>
                      </li> */}
                    </>


                  )

                }





                {/* --------------------------------------------- */}












              </ul>

            </div>
          </nav>
        </div>
        <div className="responde-vheader d-lg-none mb-0">
          <nav className="navbar navbar-expand-lg navbar-light bg-min-color mb-0 pb-0">
            <div className="navbar-toggler d-flex">
              <button class="navbar-toggler text-white" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon text-white"></span>
              </button>

            </div>

            <a className="navbar-brand" href="#">
              <div className="d-flex mx-3 ">
                <Link to={"Login"} className=''>
                  <span className="mx-2 text-white"> <i className="fa-solid fa-user font-17"></i></span>
                </Link>
                <span className="mx-2 text-white"> <i className="fas fa-search font-17"></i></span>
                <Link to={"Cart"}>
                  <span className="mx-2 text-white"> <i className="fa-solid fa-cart-shopping font-17"></i></span>

                </Link>



              </div>
            </a>


            <div className="collapse navbar-collapse" id="navbarSupportedContent">
              <ul className="navbar-nav mr-auto">
                <li className="nav-item active">
                  <div className="accordion" id="accordionExample">

                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingTwo">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#collapseTwo"
                          aria-expanded="false" aria-controls="collapseTwo">
                          كمبيوتر
                        </button>
                      </h2>
                      <div id="collapseTwo" className="accordion-collapse collapse"
                        aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the second item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingThreeeer">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#collapseThreeee"
                          aria-expanded="false" aria-controls="collapseThreeee">
                          لاب توب
                        </button>
                      </h2>
                      <div id="collapseThreeee" className="accordion-collapse collapse"
                        aria-labelledby="headingThreeeer" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingThree2">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#collapseTffouer"
                          aria-expanded="false" aria-controls="collapseTffouer">
                          تلفونات وموبايل
                        </button>
                      </h2>
                      <div id="collapseTffouer" className="accordion-collapse collapse"
                        aria-labelledby="headingThree2" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingThree3">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#collapseThree20"
                          aria-expanded="false" aria-controls="collapseThree20">
                          الاجهزه المنزليه
                        </button>
                      </h2>
                      <div id="collapseThree20" className="accordion-collapse collapse"
                        aria-labelledby="headingThree3" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingThree4">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#collapseThre10e"
                          aria-expanded="false" aria-controls="collapseThre10e">
                          انظمة الكاشير
                        </button>
                      </h2>
                      <div id="collapseThre10e" className="accordion-collapse collapse"
                        aria-labelledby="headingThree4" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingThree5">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#colla1020pseThree"
                          aria-expanded="false" aria-controls="colla1020pseThree">
                          اجهزه المراقبه الامنيه
                        </button>
                      </h2>
                      <div id="colla1020pseThree" className="accordion-collapse collapse"
                        aria-labelledby="headingThree5" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                    <div className="accordion-item">
                      <h2 className="accordion-header mx-4" id="headingThree6">
                        <button className="accordion-button collapsed" type="button"
                          data-bs-toggle="collapse" data-bs-target="#collapsesex"
                          aria-expanded="false" aria-controls="collapsesex">
                          استعمال خارجي
                        </button>
                      </h2>
                      <div id="collapsesex" className="accordion-collapse collapse"
                        aria-labelledby="headingThree6" data-bs-parent="#accordionExample">
                        <div className="accordion-body">
                          <strong>This is the third item's accordion body.</strong> It is hidden by
                          default, until the collapse plugin adds the appropriate classNamees that we use
                          to
                          style each element. These classNamees control the overall appearance, as well as
                          the
                          showing and hiding via CSS transitions. You can modify any of this with
                          custom
                          CSS or overriding our default variables. It's also worth noting that just
                          about
                          any HTML can go within the <code>.accordion-body</code>, though the
                          transition
                          does limit overflow.
                        </div>
                      </div>
                    </div>
                  </div>


                </li>
                <div className=" bg-white mt-0">
                  <div className="mx-3">
                    <h6 className="mt-3 text-danger fw-bold mx-4">افضل العروض</h6>
                    <div className="w-100 mt-3 mb-3 h-1"></div>
                    <label htmlFor="" className="text-color mx-4">اللغه</label>
                    <select className="form-select mt-1 w-25 mx-4" aria-label="Default select example">
                      <option selected>العربيه</option>
                      <option defaultValue="1">One</option>
                      <option defaultValue="2">Two</option>
                      <option defaultValue="3">Three</option>
                    </select>
                    <div className="w-100 mt-3 mb-3 h-1"></div>
                    <div className="mt-3">
                      <h6 className="fw-bold text-color mt-2 mx-4">تحتاج للمساعده؟</h6>
                      <div className="mt-2 d-flex mx-4">
                        <span className="mx-2"><i className="fa-solid fa-phone"></i></span>
                        <span className="mx-2">اتصل بنا 010555</span>

                      </div>
                      <div className="mt-2 d-flex mx-4">
                        <span className="mx-2"><i className="fa fa-envelope" aria-hidden="true"></i></span>
                        <span className="mx-2"> info@kimostore.net</span>

                      </div>
                      <div className="w-100 mt-3 mb-3 h-1"></div>

                      <h6 className="fw-bold text-color mx-4">إنضم الي متابعينا</h6>
                      <div className="mt-2 d-flex hover-icone-header mx-4">
                        <div className="mx-2 icone-hoder d-center"><i className="fa fa-envelope"
                          aria-hidden="true"></i></div>
                        <span className="mx-2"> Facebook</span>
                      </div>
                      <div className="mt-2 d-flex hover-icone-header mx-4">
                        <div className="mx-2 icone-hoder d-center"><i className="fa-brands fa-instagram"></i>
                        </div>
                        <span className="mx-2"> instagram</span>
                      </div>
                      <div className="mt-2 d-flex hover-icone-header mx-4">
                        <div className="mx-2 icone-hoder d-center"><i className="fa-brands fa-youtube"></i>
                        </div>
                        <span className="mx-2"> Yuotube</span>
                      </div>
                      <div className="mt-2 d-flex hover-icone-header mx-4">
                        <div className="mx-2 icone-hoder d-center"><i className="fa-brands fa-tiktok"></i></div>
                        <span className="mx-2"> tiktok</span>
                      </div>
                      <div className="mt-2 d-flex hover-icone-header mx-4">
                        <div className="mx-2 icone-hoder d-center"><i className="fa-brands fa-linkedin-in"></i>
                        </div>
                        <span className="mx-2"> linkedin</span>
                      </div>
                    </div>

                  </div>
                </div>

              </ul>

            </div>
          </nav>
        </div>
      </div>

    </> : ""}





    {/* <nav className="navbar navbar-expand-lg bg-body-tertiary">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">
          <img src={logo} alt="fresh cart logo" />
        </Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
          <ul className="navbar-nav me-auto mb-2 mb-lg-0">
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/products">Products</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/categories">Categories</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/brands">Brands</Link>
            </li>

          </ul>
          <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
            <li className="nav-item d-flex align-items-center">
              <i className='fab mx-2 fa-facebook'></i>
              <i className='fab mx-2 fa-twitter'></i>
              <i className='fab mx-2 fa-instagram'></i>
              <i className='fab mx-2 fa-youtube'></i>
              <i className='fab mx-2 fa-tiktok'></i>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/login">Login</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/register">Register</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" >Logout</Link>
            </li>
         

          </ul>

        </div>
      </div>
    </nav> */}
  </>
}
