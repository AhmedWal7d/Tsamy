import React from 'react';
import styles from './Products.module.css';

export default function Products() {
  return <>
    <h1>Products</h1>
  </>
}
