import React from 'react';
import styles from './Cart.module.css';

export default function Cart() {
  return <>
    <h1>Cart</h1>
  </>
}
