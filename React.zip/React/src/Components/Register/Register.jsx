import React, { useState } from 'react';
import styles from './Register.module.css';
import { useFormik } from 'formik';
import * as yup from "yup"
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';

export default function Register() {
  let Navigate = useNavigate()
  const [error, seterror] = useState(null)
  const [isLoding, setisLoding] = useState(false)

  async function onSubmit(value) {
    try {
      setisLoding(true);
      let { data } = await axios.post("https://cmask.net/front-api/register?lang=en", value)
      .catch(
        (err) => {
            console.log(err);
        //   setisLoding(false)
          seterror(err)
        }
        // (error )=> console.log(error.response.data.message)
      )
      console.log(value); // اطبع الاستجابة من الخادم
      if (data.status == true) {
        setisLoding(false);
        Navigate("/Login");
      }


    } catch (error) {
      setisLoding(false);
      if (error.response) {
        console.error("Server Error:", error.response.data);
        seterror(error.response.data.message); 
      } else {
        console.error("Error:", error.message);
        seterror("An error occurred");
      }
    }
  }
  
  function validate(value) {
    // Navigate("/Login");
    console.log(value);
  }

  const egyptianPhoneNumberPattern = /^(\+201|01|00201)[0-2,5]{1}[0-9]{8}/;
  let validationSchema = yup.object({
    name: yup.string().min(3, "min is 3").max(10, "max is 10").required("not required"),
    email: yup.string().email().required("required"),
    phone: yup.string().matches(egyptianPhoneNumberPattern, "phone not egypt").required(),
    password: yup.string().matches(/^[A-Z][a-z0-9]{5,10}/, "password is not required").required(),
    password_confirmation: yup.string().oneOf([yup.ref("password")]).required(),
    address: yup.string().min(3, "min is 3").max(10, "max is 10").required("not required"),
  })

  let formik = useFormik({
    initialValues: {
      name: "",
      phone: "",
      email: "",
      password: "",
      password_confirmation: "",
      address: "",
    }, validationSchema,
    onSubmit: onSubmit
  })

  return <>
    <div className='w-50 mx-auto py-5'>
      {error ? <div className='alert alert-danger'>{error}</div> : ""}

      <form onSubmit={formik.handleSubmit}>
        <h5 className='fw-bold text-center'>Create my account</h5>

        <label htmlFor='name' className='mt-2'>Name:</label>
        <input type='text' className='form-control mt-2 ' id="name" onBlur={formik.handleBlur} name='name' value={formik.values.name} onChange={formik.handleChange} />
        {formik.errors.name && formik.touched.name ? <div className='alert alert-danger'>{formik.errors.name}</div> : ""}

        <label htmlFor='email' className='mt-2'>Email:</label>
        <input type='email' className='form-control mt-2 ' id="email" onBlur={formik.handleBlur} name='email' value={formik.values.email} onChange={formik.handleChange} />
        {formik.errors.email && formik.touched.email ? <div className='alert alert-danger'>{formik.errors.email}</div> : ""}

        <label htmlFor='phone' className='mt-2'>Phone:</label>
        <input type='tel' className='form-control mt-2 ' id="phone" onBlur={formik.handleBlur} name='phone' value={formik.values.phone} onChange={formik.handleChange} />
        {formik.errors.phone && formik.touched.phone ? <div className='alert alert-danger'>{formik.errors.phone}</div> : ""}

        <label htmlFor='password' className='mt-2'>Password:</label>
        <input type='password' className='form-control mt-2 ' id="password" onBlur={formik.handleBlur} name='password' value={formik.values.password} onChange={formik.handleChange} />
        {formik.errors.password && formik.touched.password ? <div className='alert alert-danger'>{formik.errors.password}</div> : ""}

        <label htmlFor='password_confirmation' className='mt-2'>Confirm Password:</label>
        <input type='password' className='form-control mt-2 ' id="password_confirmation" onBlur={formik.handleBlur} name='password_confirmation' value={formik.values.password_confirmation} onChange={formik.handleChange} />
        {formik.errors.password_confirmation && formik.touched.password_confirmation ? <div className='alert alert-danger'>{formik.errors.password_confirmation}</div> : ""}

        <label htmlFor='address' className='mt-2'>Address:</label>
        <input type='text' className='form-control mt-2 ' id="address" onBlur={formik.handleBlur} name='address' value={formik.values.address} onChange={formik.handleChange} />
        {formik.errors.address && formik.touched.address ? <div className='alert alert-danger'>{formik.errors.address}</div> : ""}

        {
          isLoding ? <button className='btn bg-mainbtn-add-card mt-2' type="button">
            <button className='btn bg-color  btn-add-card '>  <i class="fas fa-spinner fa-spin"></i></button>
          </button> :
            <button disabled={!(formik.isValid && formik.dirty)} className='btn btn-add-card w-100 border-radius p-8' type="submit">Register</button>

        }
        <p className='mt-3'>This site is protected by reCAPTCHA and the Google Privacy Policy and Terms of Service apply.</p>
        <div className='d-center flex-column'>
          <div className='d-flex'>
          <p className='mx-3 mt-3'>Already have an account?</p>
            <Link to={"/Login"} className='mt-3'>Login here</Link>
          </div>

            <div class="mt-3 w-50">
                        <button class="btn btn-add-card p-8 w-100 border-radius background-facebook d-flex justify-content-center align-items-center">  
                        <div class="d-flex m-0 p-0">
                            <p class="text-white mx-2 m-0 p-0">Sign in With Facebook</p>
                            <span class="text-white"><i class="fa-brands fa-facebook-f"></i></span>
                        </div>    
                        </button>
                    </div>
                    <div class="mt-2 w-50">
                        <button class="btn btn-add-card bg-danger w-100 border-radius d-flex justify-content-center p-8 align-items-center">  
                        <div class="d-flex m-0 p-0">
                            <p class="text-white mx-2 m-0 p-0">Sign in With Google</p>
                            <span class="text-white"><i class="fa-brands fa-google"></i></span>
                        </div>    
                        </button>
                    </div>



        </div>
      </form>
    </div>
  </>
}
