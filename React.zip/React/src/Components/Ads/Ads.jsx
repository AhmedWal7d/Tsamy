import axios from 'axios'
import React from 'react'
import { useQuery } from 'react-query'

import Slider from "react-slick";


export default function Ads() {


 
    function getCatogry(){
        return axios.get(`https://cmask.net/front-api/home?lang=en`)
    }

    let {isError , data , isLoading} = useQuery("catogrySlider" , getCatogry)

    // console.log(data?.data.data.slider.id , "Ahmed0111");

  return <>

      
      
  {
    data?.data.data.default_ads? <div className='container-fluid'>
    <div className='row mt-5'>
      <div className='col-sm-12'>
          <img src={data?.data.data.default_ads.image_name}  className='w-100'/>
      </div>
     
        { data?.data.data.other_ads.map((imgAds)=> <>  
         <div className='col-md-4 mt-5'>
         <div className='discount-img'>
         <img className='w-100' src={imgAds.image_name}/>
         </div>
        
         </div>
        
      </>  )}
    </div>
  

        {/* {data?.data.data.default_ads.map((ategorie) => <img src={ategorie.image_name} />) } */}

    </div>    : ""
   
      
 
   }

   
   
      
 

  </>
}
